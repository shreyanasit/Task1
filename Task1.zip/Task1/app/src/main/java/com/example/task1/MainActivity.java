package com.example.task1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvTitle;
    Button btnRed, btnGreen;
    LinearLayout llMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvTitle     = findViewById(R.id.tvTitle);
        btnRed      = findViewById(R.id.btnRed);
        btnGreen    = findViewById(R.id.btnGreen);
        llMain      = findViewById(R.id.llMain);

        btnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llMain.setBackgroundColor(Color.RED);
                tvTitle.setText("Red Background");
            }
        });

        btnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llMain.setBackgroundColor(Color.GREEN);
                tvTitle.setText("Green Background");
            }
        });

    }
}